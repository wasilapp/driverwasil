import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF15CB95);
const Color secondaryColor = Colors.black;
const Color backgroundColor = Colors.white;